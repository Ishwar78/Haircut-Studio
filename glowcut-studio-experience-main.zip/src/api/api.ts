const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || "http://localhost:5000/api";

export const apiCall = async (endpoint: string, options: RequestInit = {}) => {
  const response = await fetch(`${API_BASE_URL}${endpoint}`, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      ...options.headers,
    },
  });

  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.message || "Something went wrong");
  }

  return response.json();
};

export const adminApi = {
  login: (credentials: any) => apiCall("/admin/login", {
    method: "POST",
    body: JSON.stringify(credentials),
  }),
  getStats: () => apiCall("/admin/dashboard-stats"),
  // Explore Gallery
  getExplore: () => apiCall("/explore"),
  addExplore: (formData: FormData) => fetch(`${import.meta.env.VITE_API_BASE_URL || "http://localhost:5000/api"}/explore`, {
    method: "POST",
    body: formData,
  }).then(res => res.json()),
  deleteExplore: (id: string) => apiCall(`/explore/${id}`, {
    method: "DELETE",
  }),
};
